
from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib.parse


class AnimalShelter(object):

    #property variables
    records_updated = 0 #keep a record of the records updated in an operation;
    records_matched = 0 #keep a record of the records macthed in an operation;
    records_deleted = 0 #keep a record of the records deleted in an operation;

    #constructor to init the mongodb
    #to do: this should be a singleton
    def __init__(self, _password, _username = 'aacuser'):

        #URI must be percent escaped as per pymongo documentation
        username = urllib.parse.quote_plus(_username)
        password = urllib.parse.quote_plus(_password)

        self.client = MongoClient('mongodb://%s:%s@localhost:37477/?authSource=AAC' % (username, password))
        self.dataBase = self.client['AAC']

    # Read method
    def read(self, query):
        if query is not None:
            results = self.dataBase.animals.find(query, {"_id": 0})  # find results of query
            if results.count() != 0:
                #for document in results:  # iterate through the results
                #    pprint(document)  # output the results
                return results
            else:
                return False  # no results found
        else:
            raise Exception("No search parameter entered.")
        return results

    #Mehtod to create a record
    #Input data formatted as per the Pymongo API
    #Example: ({""name": "Rex", 'age_upon_outcome': '2 months'})
    def createRecord(self, data):
        if data:
            _insertValid = self.dataBase.animals.insert_one(data)
            #check the status of the inserted value
            return True if _insertValid.acknowledged else False

        else:
            raise Exception("No document to save. Data is empty.")

    #todo implement the R
    #get documents by the GUID
    #This is more for a test but could be used after the createRecord
    #Since the document returned by insert_one contains the newly created _id
    def getRecordId(self, postId):
        _data = self.dataBase.find_one({'_id': ObjectId(postId)})

        return _data

    #Get records with criteria
    #All records are returned if criteria is None
    #Default is None
    #Example: ({""name": "Rex", 'age_upon_outcome': '2 months'})
    #do not return the _id
    def getRecordCriteria(self, criteria):
        if criteria:
            _data = self.dataBase.animals.find(criteria, {'_id' : 0})

        else:
            _data = self.dataBase.animals.find({},{'_id' : 0})

        return _data

    #Update a record
    def updateRecord(self, query, newValue):
        if not query:
            raise Exception("No search criteria is present.")
        elif not newValue:
            raise Exception("No update value is present.")
        else:
            _updateValid = self.dataBase.animals.update_many(query, {"$set": newValue})
            self.records_updated = _updateValid.modified_count
            self.records_matched = _updateValid.matched_count

            return True if _updateValid.modified_count > 0 else False

    #delete a record
    def deleteRecord(self, query):
        if not query:
            raise Exception("No search criteria is present.")

        else:
            _deleteValid = self.dataBase.animals.delete_many(query)
            self.records_deleted = _deleteValid.deleted_count

            return True if _deleteValid.deleted_count > 0 else False